module.exports = ctx => ({
	map: false,
  plugins: {
    'postcss-preset-env': {
      stage: 0,
    }
  }
});
